import getElementsFromRecords from './getElementsFromRecords';
import InferredElement from './InferredElement';

export { getElementsFromRecords, InferredElement };
