import defaultMessages from 'ra-language-english';

export default () => defaultMessages;
