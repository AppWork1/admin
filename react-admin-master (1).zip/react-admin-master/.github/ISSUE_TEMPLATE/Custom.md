---
name: "\U0001F4AC Support Question"
about: If you have a "How to" question, please check out StackOverflow!

---

We primarily use GitHub as an issue tracker; for usage and support questions, please use StackOverflow(http://stackoverflow.com/questions/tagged/react-admin using the tag `react-admin`). Thanks! 😁.
