# React-admin simple

This is the application we use for our end to end tests.

## How to run

After having cloned the react-admin repository, run the following commands:

```sh
make install

make run-simple
```

And then browse to [http://localhost:8080/](http://localhost:8080/).

The credentials are **login/password**
